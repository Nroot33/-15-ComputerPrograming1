import java.util.Scanner;

public class cm {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int x;
		double y,z;
		System.out.print("Ű�� �Է��Ͻÿ�: ");
		x = input.nextInt();
		y = (x/2.54)/12;
		z = (x/2.54)%12;
		System.out.print(x+"cm��"+(int)y+"��Ʈ"+z+"��ġ�Դϴ�.");
	}
}