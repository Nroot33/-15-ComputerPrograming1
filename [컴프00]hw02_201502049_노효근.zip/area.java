import java.util.Scanner;

public class area {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int x;
		double y;
		System.out.print("�� ���Դϱ�?: ");
		x = input.nextInt();
		y = x*3.3058;
		System.out.print(y+"�������Դϴ�.");
	}
}