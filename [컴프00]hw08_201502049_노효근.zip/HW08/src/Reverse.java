import java.util.Scanner;

public class Reverse {


	public void reverse(String str) 
	{
		 for(int i=str.length()-1; i>=0; i--)
			 System.out.print(str.charAt(i));
	}

	public void input() {
		Scanner input = new Scanner(System.in);
		System.out.print("���� �Է� : ");
		String s = input.next();
		reverse(s);
	}

	public static void main(String[] args){
		Reverse test = new Reverse();
		test.input();
	}
}