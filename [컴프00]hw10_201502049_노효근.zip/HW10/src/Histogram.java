import java.util.Scanner;
public class Histogram {
	public static void main(String arg[]){
		Scanner input = new Scanner(System.in);
		int []hist = new int[10];
		int []num = new int[10];
		
		for(int i=0; i<10; i++){
			num[i] =  input.nextInt();
			hist[i] = 0;
		}
		for(int v:num)
			for(int j =0; j<10; j++)
				if(v<=(j+1)*10){hist[j]++; break;}
		
		for(int i=0; i<10; i++){
			System.out.println((i*10+1)+" ~ "+(i*10+10));

			for(int j=0; j<hist[i]; j++)
				System.out.print("*");
			System.out.println();
		}
	}
}
