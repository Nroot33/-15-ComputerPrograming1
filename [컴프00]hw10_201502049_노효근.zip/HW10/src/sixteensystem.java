import java.util.Scanner;
public class sixteensystem {
	public static void main(String arg[]){

		Scanner input = new Scanner(System. in);
		System.out.println("16 ���� ���ڿ��� �Է��Ͻÿ� : ");
		String n = input.next();
		

		String []hexa2bin = {"0000","0001","0010","0011","0100"
				,"0101","0110","0111","1000","1001","1010","1011","1100","1101","1110","1111"};
		
		char b[] = n.toCharArray();
		
		for(int i=0; i<n.length(); i++)	{
			if(b[i] == '0')
				System.out.print(" "+hexa2bin[0]);
			if(b[i] == '1')
				System.out.print(" "+hexa2bin[1]);
			if(b[i] == '2')
				System.out.print(" "+hexa2bin[2]);
			if(b[i] == '3')
				System.out.print(" "+hexa2bin[3]);
			if(b[i] == '4')
				System.out.print(" "+hexa2bin[4]);
			if(b[i] == '5')
				System.out.print(" "+hexa2bin[5]);
			if(b[i] == '6')
				System.out.print(" "+hexa2bin[6]);
			if(b[i] == '7')
				System.out.print(" "+hexa2bin[7]);
			if(b[i] == '8')
				System.out.print(" "+hexa2bin[8]);
			if(b[i] == '9')
				System.out.print(" "+hexa2bin[9]);
			if(b[i] == 'a')
				System.out.print(" "+hexa2bin[10]);
			if(b[i] == 'b')
				System.out.print(" "+hexa2bin[11]);
			if(b[i] == 'c')
				System.out.print(" "+hexa2bin[12]);
			if(b[i] == 'd')
				System.out.print(" "+hexa2bin[13]);
			if(b[i] == 'e')
				System.out.print(" "+hexa2bin[14]);
			if(b[i] == 'f')
				System.out.print(" "+hexa2bin[15]);		
		}
	}
}
