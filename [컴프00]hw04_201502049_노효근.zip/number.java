import java.util.Scanner;
public class number
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int a, b, c, d, temp;
		System.out.println("ū ���ڼ����� �����մϴ�"); 
		System.out.println("���� 4���� �Է��Ͻÿ�:");
		a = input.nextInt();
		b = input.nextInt();
		c = input.nextInt();
		d = input.nextInt();
		System.out.println();
		if( a > b ) {
			temp = a;
			a = b;
			b = temp;
		}
		if( b > c ) {
			temp = b;
			b = c;
			c = temp;
		}
		if( c > d ) {
			temp = c;
			c = d;
			d = temp;
		}
		if ( a > b ) {
			temp = a;
			a = b;
			b = temp;
		}
		if ( b > c ) {
			temp = b;
			b = c;
			c = temp;
		}

		if ( a > b ) {
			temp = a;
			a = b;
			b = temp;
		}
		System.out.print(d+","+c+","+b+","+a);
	}
}
