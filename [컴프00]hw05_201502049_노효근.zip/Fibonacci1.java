public class Fibonacci1 {

	public static void main(String[] args) {
		int i;
		int a =0,b=1,c;	
		for (i = 2; i<=10; i++){
			System.out.print(a+" ");
			System.out.printf("\t");
			c=a+b;
			a=b;
			b=c;	
		}
	}
}