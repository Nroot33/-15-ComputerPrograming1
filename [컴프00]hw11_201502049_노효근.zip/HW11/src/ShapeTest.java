
public class ShapeTest {
	public static void main(String arg[]){
		Shape S = new Shape();
		Rectangle R = new Rectangle(3,4);
		Triangle T = new Triangle(4,5);
		Circle C = new Circle(6);

		S.Area();
		R.Area();
		T.Area();
		C.Area();

		S.Perimeter();
		R.Perimeter();
		T.Perimeter();
		C.Perimeter();

		S.print();
		R.print();
		T.print();
		C.print();
	} 
}
