public class Shape {
	int x,y,a,p;

	public Shape(){

	}

	public Shape(int x, int y){
		this.x = x;
		this.y = y;
	}
	public int getX(){return x;}
	public void setX(int x){ this.x = x;}
	public int getY(){return y;}
	public void setY(int y){ this.y = y;}


	public void Area(){
	}

	public void Perimeter(){

	}

	public void print(){
		System.out.println("���� �׸���");
	}
}
	class Rectangle extends Shape{
		int x,y,a,p;

		public Rectangle(){

		}

		public Rectangle(int x, int y){
			this.x = x;
			this.y = y;
		}
		
		public int getX(){return x;}
		public void setX(int x){ this.x = x;}
		public int getY(){return y;}
		public void setY(int y){ this.y = y;}



		@Override
		public void Area(){
			a = x*y;
		}

		@Override
		public void Perimeter(){
			p = 2*(x+y);
		}

		@Override
		public void print(){
			System.out.println("�簢�� �����");
			System.out.println("����: "+a+" �ѷ�: "+p);
		}
	}

	class Triangle extends Shape{
		int x,y,a,p;

		public Triangle(){

		}

		public Triangle(int x, int y){
			this.x = x;
			this.y = y;
		}
		public int getX(){return x;}
		public void setX(int x){ this.x = x;}
		public int getY(){return y;}
		public void setY(int y){ this.y = y;}

		@Override
		public void Area(){
			a = (x*y)/2;
		}

		@Override
		public void Perimeter(){
			p = 3*x;
		}

		@Override
		public void print(){
			System.out.println("�ﰢ�� �����");
			System.out.println("����: "+a+" �ѷ�: "+p);
		}
	}

	class Circle extends Shape{
		int x;
		double a,p;

		public Circle(){

		}

		public Circle(int x){
			this.x = x;
		}
		public int getX(){return x;}
		public void setX(int x){ this.x = x;}

		@Override
		public void Area(){
			a = x*x*Math.PI;
		}

		@Override
		public void Perimeter(){
			p = 2*x*Math.PI;
		}

		@Override
		public void print(){
			System.out.println("�� �����");
			System.out.println("����: "+a+" �ѷ�: "+p);
		}
	}


