
public class BankAccountTest {
	public static void main(String[] args){
		BankAccount b1,b2,b3;
		b1 = new BankAccount("ȫ�浿","1561060460123");
		b2 = new BankAccount("������","5064502320104",50000);
		b3 = new BankAccount("��ȿ��","9013154321347",100000,2.9);
		b1.print();
		b2.print1();
		b3.print2();
	}
}
