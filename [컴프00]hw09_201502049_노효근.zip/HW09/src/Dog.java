class Dog {
	private String name = null;
	public String breed = null;
	private int age = 0; 

	public Dog(String name,int age){
		name = this. name;
		age = this. age;
	}

	public Dog(String name, String breed, int age){
		name = this. name;
		breed = this. breed;
		age = this. age;
	}
}
