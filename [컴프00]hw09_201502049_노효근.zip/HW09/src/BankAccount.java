class BankAccount {
	private String name;
	private String account;
	private int money;
	private double interestrate;

	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	public String getAccount() {return account;}
	public void setAccount(String account) {this.account = account;}
	public int getMoney() {return money;}
	public void setMoney(int money) {this.money = money;}
	public double getInterestrate() {return interestrate;}
	public void setInterestrate(double interestrate) {this.interestrate = interestrate;}

	public BankAccount(String n, String a){
		name = n;
		account = a;
	}
	public BankAccount(String n, String a, int m){
		name = n;
		account = a;
		money = m;

	}
	public BankAccount(String n, String a, int m, double i){
		name = n;
		account = a;
		money = m;
		interestrate = i;
	}

	void print(){
		System.out.println("�̸�: "+name+" ���¹�ȣ: "+account);
	}
	void print1(){
		System.out.println("�̸�: "+name+" ���¹�ȣ: "+account+" �ܾ�: "+money);
	}
	void print2(){
		System.out.println("�̸�: "+name+" ���¹�ȣ: "+account+" �ܾ�: "+money+" ������: "+interestrate);
	}
}
