class Movie {
	private String title;
	private String director;
	private String company;

	public String getTitle() {return title;}
	public void setTitle(String title) {this.title = title;}
	public String getDirector() {return director;}
	public void setDirector(String director) {this.director = director;}
	public String getCompany() {return company;}
	public void setCompany(String company) {this.company = company;}

	public Movie(String t, String d, String c){
		title = t;
		director = d;
		company = c;
	}

	void print(){
		System.out.println("����: "+title+"����: "+director+"���ۻ�: "+company);
	}
}
