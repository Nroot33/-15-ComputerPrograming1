
public class BoxTest {

	public static void main(String[] args) {
		Box b1,b2,b3;
		b1 = new Box(10, 10, 10);
		b2 = new Box(20, 20, 20, true);
		b3 = new Box();
		
		b1.print();
		b2.print1();
		b3.print2();
	}
}
