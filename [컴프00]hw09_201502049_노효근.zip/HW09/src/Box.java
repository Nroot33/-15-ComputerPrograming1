class Box {
	private int length;
	private int wide;
	private int height;
	private boolean empty = true;
	public int getLength() {return length;}
	public void setLength(int length) {this.length = length;}
	public int getWide() {return wide;}
	public void setWide(int wide) {this.wide = wide;}
	public int getHeight() {return height;}
	public void setHeight(int height) {this.height = height;}
	public boolean isEmpty() {return empty;}
	public void setEmpty(boolean empty) {this.empty = empty;}

	public Box(int l, int w, int h){
		length = l;
		wide = w;
		height = h;
	}

	public Box(int l, int w, int h, boolean e){
		length = l;
		wide = w;
		height = h;
		empty = e;
	}

	public Box(){}
	
	void print(){
		System.out.println("����: "+length+" �ʺ�: "+wide+" ����: "+height);
	}
	void print1(){
		System.out.println("����: "+length+" �ʺ�: "+wide+" ����: "+height+" ����ֳ���?: "+empty);
	}
	void print2(){
		System.out.println("���ڰ� �����ϴ�.");
	}
}

