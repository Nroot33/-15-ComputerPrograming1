public class Point {
	int px;
	int py;

	void setset(int x, int y)
	{
		px = x;
		py = y;
	}
	void getset()
	{
		return;
	}
	void print()
	{
		System.out.println("x��ǥ: "+px+" y��ǥ: "+py);
	}

	public static void main(String[] args){
		Point Pointtest = new Point();
		Pointtest.setset(5, 6);
		Pointtest.print();
	}
}