public class Dice {
	int face;
	void roll()
	{
		face = (int)(Math.random()*6)+1;
	}

	void print()
	{
		System.out.println(face);
	}
}
