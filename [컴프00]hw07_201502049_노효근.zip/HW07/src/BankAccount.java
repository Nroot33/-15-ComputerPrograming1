public class BankAccount {

	public int amount;
	public int bankaccount;
	public int otheraccount;

	void setAmount(int a){amount=a;}
	int getAmount(){return amount;}
	void setBankAccount(int b){bankaccount=b;}
	int getBankAccount(){return bankaccount;}
	void setOtherAccount(int o){otheraccount=o;}
	int getOthrAccount(){return otheraccount;}

	int gettransfer1()
	{
		return otheraccount+=amount;
	}
	int gettransfer2()
	{
		return bankaccount-=amount;
	}
	
	void print1()
	{
		System.out.println("���� ���� �ܾ�: "+bankaccount);
		System.out.println("�۱��� �ݾ�: "+amount);
		System.out.println("�۱ݹ޴� ������ �ܾ�: "+otheraccount);
	}
	void print2()
	{
		System.out.println("���� ���� �ܾ�: "+bankaccount);
		System.out.println("�۱ݹ��� �� ������ �ܾ�: "+otheraccount);
	}

	public static void main(String[] args){
		BankAccount transfer = new BankAccount();

		transfer.setBankAccount(50000);
		transfer.setAmount(10000);
		transfer.setOtherAccount(50000);

		transfer.print1();
		transfer.gettransfer1();
		transfer.gettransfer2();
		transfer.print2();
	}
}

