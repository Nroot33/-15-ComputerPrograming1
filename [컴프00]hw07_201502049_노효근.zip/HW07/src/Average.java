public class Average {
static int ax;
static int bx;
static int cx;
	
void setAX(int a){ax=a;}
int getAX(){return ax;}
void setBX(int b){bx=b;}
int getBX(){return bx;}
void setCX(int c){cx=c;}
int getCX(){return cx;}

	double getAverage(int a,int b)
	{
		return (a+b)/2;
	}
	
	double getAverage(int a,int b,int c)
	{
		return (a+b+c)/3;
	}
	
	void print1()
	{
		System.out.print("�� ���� ���� : "+ax);
		System.out.println(" " +bx);
	}
	
	void print2()
	{
		System.out.print("�� ���� ���� : "+ax);
		System.out.print(" " +bx);
		System.out.println(" " +cx);
	}
	public static void main(String[] args){
		Average AverageTest = new Average();

		AverageTest.setAX(3);
		AverageTest.setBX(5);
		AverageTest.setCX(7);

		AverageTest. print1();
		System.out.println(AverageTest.getAverage(ax, bx));
		
		AverageTest. print2();
		System.out.println(AverageTest.getAverage(ax, bx, cx));
	}
}

