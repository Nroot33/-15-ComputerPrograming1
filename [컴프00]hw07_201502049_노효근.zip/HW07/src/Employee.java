public class Employee {
	String name;
	String phone;
	int salary;

	void setName(String n){name=n;}
	String getName() {return name;}
	void setPhone(String p ){phone = p;}
	String getPhone() {return phone;}
	void setSalary(int s){salary=s;}
	int getSalary() {return salary;}

	void print()
	{
		System.out.println("�̸�: "+name);
		System.out.println("��ȭ��ȣ: "+phone);
		System.out.println("����: "+salary);
	}
	public static void main(String[] args){
		Employee EmployeeTest = new Employee();

		EmployeeTest.setName("��ȿ��");
		EmployeeTest.setPhone("01051151844");
		EmployeeTest.setSalary(1000000000);
		EmployeeTest. print();
	}
}
